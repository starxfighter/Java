public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean pt = new Pythagorean();
        double result = pt.calculateHypotenuse(7, 8);
        System.out.println("The value is: " + result);
    }
}

